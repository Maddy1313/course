import UIKit

var str = "Hello, playground"

//1. Write a Swift program to check if two given arrays of integers have 0 as their first element.
//произвести проверку двух массивов(Int) являются ли их первые элементы нулями и вывести соответствующее сообщение в консоль.
func checkZero (_ array1:[Int], _ array2:[Int]) -> Bool{
    var value1 = 0
    if array1.first == 0{
        value1 += 1
    }
    if array2.first == 0{
        value1 += 1
    }
    if value1 == 2{
        return true
    }
    else {
        return false
    }
    
}
print(checkZero([0,3,4], [0,5]))
print(checkZero([0,3,4],[1,5]))
print([0,1][0])

//2. Write a Swift program to test if an array of integers does not contain a 3 or a 5.
//произвести проверку двух массивов(Int) на отсутствие в них элементов 3 и 5 и вывести соответствующее сообщение в консоль

func containsNothingSpare (_ array2:[Int]) -> Bool {
    if array2.contains(3) || array2.contains(5) { return false
    } else {return true
    }
}
print (containsNothingSpare([1,2,3,4,5,6,7]))
print (containsNothingSpare([1,2,4,6,7]))

//3. Write a Swift program to check whether the first element and the last element of a given array of integers are equal.
//произвести проверку одинаковы ли первый и последний элементы данного массива(Int) и вывести соответствующее сообщение в консоль
func checkWetherEqual (_ array3:[Int]) -> Bool {
    if array3.first == array3.last { return true
    } else {
        return false
    }
}
print(checkWetherEqual([123,1,4,5,6,123]))
print(checkWetherEqual([123,1,2,3,4,5]))

//4. Write a Swift program that creates Array, adds an item, remove item, modify item and then prints size of the array.
//проинициализировать массив, добавить в него элемент, удалить элемент, модифицировать какой-нибудь элемент и вывести в консоль размер массива(количество элементов)
var someArrey: [Int] = [1,2,3,4,5,6,7]
someArrey.append(17)
print(someArrey)
someArrey.remove(at: 4)
print(someArrey)
someArrey[1] = 100
print(someArrey)
let size = someArrey.count
print("Size of Set is: \(size)")

//5. Write a Swift program that creates Dictionary, adds an item, remove item, modify item and then prints size of the Dictionary.
//проинициализировать словарь, добавить в него элемент, удалить элемент, модифицировать какой-нибудь элемент и вывести в консоль размер словаря(количество элементов)
var someDictionary: [String: Int] = [
    "John Rambo":300,
    "Caster":250,
    "Matsumoto" :200
]
someDictionary.updateValue(700, forKey: "Conan")
print(someDictionary)
someDictionary.removeValue(forKey: "Caster")
print(someDictionary)
someDictionary["Matsumoto"] = 300
print(someDictionary)
let size1 = someDictionary.count
print("Size of Set is: \(size1)")



//6. Write a Swift program that creates Set, adds an item and then prints size of the Set.
////проинициализировать Сет, добавить в него элемент и вывести в консоль размер Сета(количество элементов)

var someSet: Set = ["ru", "eng", "de", "ch", "fr"]
someSet.insert("us")
var size3 = someSet.count
 print("Size of Set is: \(size3)")



//7. Create 2 arrays, and merge them.
//проинициализировать 2 массива и объединить(можно в новом массиве)
var array1 = [1,2,3,4,5,6]
var array2 = [7,8,9,10,11,12]

let uniqueArray = Array(Set(array1 + array2))
print("The result is: \(uniqueArray)")

//8. Write a closure to sum 2 integers, pass closure as argument to function, where return the result of calling that closure.
//Написать замыкание(closure), задача которого складывать 2 полученных аргумента типа Int и вернуть его и вывести в консоль.


let closure:((Int, Int) -> Int) = {
    (number1, number2) in
    return number1 + number2
}
print(closure(1,3))



//9. Подготовить примеры:
// array.map(<#T##transform: (Int) throws -> T##(Int) throws -> T#>)
// array.filter(<#T##isIncluded: (Int) throws -> Bool##(Int) throws -> Bool#>)

let someNumbers = [23, 24, 25, 26]
let doubled = someNumbers.map { $0 * 2 }


let orderOfNumbers = [1, 2, 4, 7, 21, 23, 24, 25, 27]
let filtered = orderOfNumbers.filter { word in
  return orderOfNumbers.count >= 3
}


