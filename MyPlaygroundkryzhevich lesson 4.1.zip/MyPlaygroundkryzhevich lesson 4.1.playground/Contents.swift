import UIKit

var str = "Hello, playground"
// Написать ряд функций одного объекта:
// 1. Функция принимающая 2 аргумента типа Int, сравнивает их значения и выводит в консоль результат сравнения в виде: "Аргумент 1 больше, чем Аргумент 2".

func run(slowly: Int, faster: Int){
    if slowly < faster {
        print ("Аргумент 1 больше, чем Аргумент 2")
    } else { print ("Аргумент 1 vеньше, чем Аргумент 2")
}
}

run(slowly:1, faster:2)

 
// 2. Функция получает 3 аргумента, если среди них хотя бы 2 аргумента равны, то выводит ответ в виде: "2 аргумента равны", противном случае выдать ответ "равных аргументов нет".

func fly(slow: Int, fast: Int, superFast: Int){
    if slow == fast || fast == superFast || slow == superFast {
    print ("2 аргумента равны")} else {
        print ("2 аргунемента не являются равными")}
}
fly(slow:1, fast:2, superFast:2)

// 3. Функция получает опциональный Int аргумент, затем проверяет ее на nil: если есть значение - выводит его в консоль, если нет - выводит фразу "no value"

func jump (_ power: String?) {
if power == nil {
    print("no value")
} else {
    print("Value is \(String(describing: power))")
}
}
jump(nil)
