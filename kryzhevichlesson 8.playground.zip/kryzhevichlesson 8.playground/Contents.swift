import UIKit

var str = "Hello, playground"
// HOMEWORK:
 // Implement Quick or Merge sort
var anyNumbers: [Int] = [22,1,3,45,98,17,57,82,34,21,13,2,4,7,9,10,72,54,96,78,29,68,51]

func quicksort<T: Comparable>(_ list: [T]) -> [T] {
    if list.count <= 1 {
        return list
    }

    let pivot = list.randomElement() ?? list[0]

    var smallerList = [T]()
    var equalList = [T]()
    var biggerList = [T]()

    for x in list {
        switch x {
            case let x where x < pivot:
                smallerList.append(x)
            case let x where x == pivot:
                equalList.append(x)
            case let x where x > pivot:
                biggerList.append(x)
            default:
                break
        }
    }

    return quicksort(smallerList) + equalList + quicksort(biggerList)
}
quicksort(anyNumbers)

 // Write Algorithm to check if two rectangles overlap with each other
func compareTwoRectangels (rectangelA: Int, rectangelB:Int) -> (Bool) {
    enum rectangelA{
        case sideAX (Int)
        case sideAY (Int)
        case sideAX1 (Int)
        case sideAY1 (Int)
    }
    enum rectangelB {
        case sideBX (Int)
        case sideBY (Int)
        case sideBX1 (Int)
        case sideBY1 (Int)
    }
    
    let ax = rectangelA.sideAX(2)
    let ay = rectangelA.sideAY(3)
    let ay1 = rectangelA.sideAY1(3)
    let ax1 = rectangelA.sideAX1(2)
    
    let bx = rectangelB.sideBX(3)
    let by = rectangelB.sideBY(4)
    let by1 = rectangelB.sideBY1(4)
    let bx1 = rectangelB.sideBX1(3)
    
    if ay(Int) < by1(Int) || ay1(Int) > by(Int) || ax1(Int) < bx(Int) || ax(Int) > bx1(Int) {
        print("They overlap each other")}
    return true
}



 // data structures:
 // binary tree
 // linked list https://www.geeksforgeeks.org/linked-list-vs-array/
 // https://www.raywenderlich.com/947-swift-algorithm-club-swift-linked-list-data-structure

