import UIKit

var str = "Hello, playground"
// HOMEWORK:
 // Implement Quick or Merge sort
var anyNumbers: [Int] = [22,1,3,45,98,17,57,82,34,21,13,2,4,7,9,10,72,54,96,78,29,68,51]

func quicksort<T: Comparable>(_ list: [T]) -> [T] {
    if list.count <= 1 {
        return list
    }

    let pivot = list.randomElement() ?? list[0]

    var smallerList = [T]()
    var equalList = [T]()
    var biggerList = [T]()

    for x in list {
        switch x {
            case let x where x < pivot:
                smallerList.append(x)
            case let x where x == pivot:
                equalList.append(x)
            case let x where x > pivot:
                biggerList.append(x)
            default:
                break
        }
    }

    return quicksort(smallerList) + equalList + quicksort(biggerList)
}
quicksort(anyNumbers)

 // Write Algorithm to check if two rectangles overlap with each other


struct Point {
    var x: Double
    var y: Double
}
struct Rect {
    var startNode: Point
    var endNode: Point
}
func ifIntersect (rect1: Rect, rect2: Rect) -> Bool {
    if rect1.startNode.x > rect2.endNode.x || rect1.endNode.x < rect2.startNode.x {
        print("Не пересекаются")
        return false
    } else if rect1.startNode.y < rect2.endNode.y || rect1.endNode.y < rect2.startNode.y {
        print("Не пересекаются")
        return false
    }
    return true
}



 // data structures:
 // binary tree
 // linked list https://www.geeksforgeeks.org/linked-list-vs-array/
 // https://www.raywenderlich.com/947-swift-algorithm-club-swift-linked-list-data-structure

