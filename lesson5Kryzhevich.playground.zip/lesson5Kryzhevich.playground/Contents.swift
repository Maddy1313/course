import UIKit

var str = "Hello, playground"

// 1. Придумать ENUM к которому можно применить rawValue (не Error), другой к которому можно применить Associated Values (не из примеров с занятия)

// raw value
enum currencyInThepocket: Int {
    case Usd = 17
    case Byn = 19
    case Rub = 22
    case Cty = 18
}
currencyInThepocket(rawValue: 17)

//associated value

enum CurrencyExchange {
    case usdForRub (Int)
    case ctyForUsd (Int)
    case bynForRub (Int)
}
let usdForRubExchange = CurrencyExchange.usdForRub(200)
let exchangeQuantity = 100

let ctyForUsdExchange = CurrencyExchange.bynForRub(300)
let exchangeQuantity1 = 200

func exchange1(currencyExchange: CurrencyExchange){
    switch currencyExchange {
    case .usdForRub(let amount):
    print("Confirm transaction: \(amount)")
    case .ctyForUsd(let amount):
    print("Confirm transaction: \(amount)")
    case .bynForRub(let amount):
    print("Confirm transaction: \(amount)")
    }
}
exchange1(currencyExchange: ctyForUsdExchange)






 // 2. Создать опционалы типов Int, Double, String + какого-то своего класса, а также применить все виды разворачивания: Optional Binding, Optional chaining, nil-coalesing (??)

var amountOfCoffeeBeans: Int? = 131
var diskСapacity: Double? = 256.36
var someString: String? = "Be or not to be?"
var someChar: Character? = "B"

// 1. Optional Binding

//amountOfCoffeeBeans
if let coffeBeans = amountOfCoffeeBeans {
    print("\(coffeBeans)")
}
amountOfCoffeeBeans = nil
if let coffeBeans = amountOfCoffeeBeans {
    print("\(coffeBeans)")} else {
        print("Amount of coffe beans is nil!")
}

// diskСapacity
if let diskMemory = diskСapacity {
    print("\(diskMemory)")
}
diskСapacity = nil
if let diskMemory = diskСapacity {
    print("\(diskMemory)")} else {
        print("Amount of memory is nil!")
}

// someString
if let string1 = someString {
    print("\(string1)")
}
someString = nil
if someString != nil {
    print("\("string1")")} else {
        print("Here is nothing!")
}

// someChar
if let char1 = someChar {
    print("\(char1)")
}
someChar = nil
if let char1 = someChar {
    print("\(char1)")} else {
        print("no letter")
}



// 2. Optional chaining

//amountOfCoffeeBeans






// 3. nil-coalesing

//amountOfCoffeeBeans
print(amountOfCoffeeBeans ?? "there is nil")
let nonOptional2 = amountOfCoffeeBeans ?? 131
let newInt: Int = amountOfCoffeeBeans ?? 0

// diskСapacity

print(diskСapacity ?? "there is nil")
let nonOptional3 = diskСapacity ?? Double(256.36)
let newdouble1: Double = Double(diskСapacity ?? 0)

// someString

print(someString ?? "there is nil")
let nonOptional4 = someString ?? "Be or not to be?"
let newString: String = someString ?? "equal nill"


// someChar

print(someChar ?? "there is nil")
let nonOptional5 = someChar ?? "b"
//let newChar: Character = someString ?? 0


 // 3. Описать с помощью ENUM погодные явления, сопроводить(где возможно) associated values

enum weatheConditions {
    case rain (
            type: String,
            duration: Int
         )
    case fog (
            territoryCover: Int,
            duration: Int,
            type: String
         )
    case snow(
            type: String,
            duration: Int
         )
    case tunder (
            type: String,
            duration: Int,
            destructionLevel: Int
                 )
}

