import UIKit

var str = "Hello, playground"
// Написать ряд функций одного объекта:
// 1. Функция принимающая 2 аргумента типа Int, сравнивает их значения и выводит в консоль результат сравнения в виде: "Аргумент 1 больше, чем Аргумент 2".

class Cats {
    func jump(value: Int){}
    func run(value: Int){}
    func bite(bite1: Int, bite2: Int, bite3: Int, bite4: Int?) -> String
    { let bite1: Int = 5
        let bite2: Int = 3
        let bite3: Int = 5
        let bite4: Int? = 1
        if bite1 > bite2 {return ("Аргумент 1 больше Аргумента 2")}
        else
        {if bite1 == bite2 || bite2 == bite3 || bite1 == bite3 {return("2 аргумента равны")}
        else {var result: Int? = bite4!}
            {if bite4 > 0 {return (var result)}}
            else {if bite <= 0 {return print("no value")}}
        
        else {
            print ("no value")
            return "Аргумент 1 меньше Аргумента 2"
    }
}
}
}



 
// 2. Функция получает 3 аргумента, если среди них хотя бы 2 аргумента равны, то выводит ответ в виде: "2 аргумента равны", противном случае выдать ответ "равных аргументов нет".

    

// 3. Функция получает опциональный Int аргумент, затем проверяет ее на nil: если есть значение - выводит его в консоль, если нет - выводит фразу "no value"
